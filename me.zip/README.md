# PORTFOLIO-APP 
[![Build Status](https://travis-ci.org/dbarochiya/me.svg?branch=master)](https://travis-ci.org/dbarochiya/me)

This is the implementaion code for the blog I have written '[How to create your portfolio website using React.js](https://medium.freecodecamp.org/portfolio-app-using-react-618814e35843)'
- To run this project follow these steps , 
  - clone the repo using `git clone`
  - navigate to folder `portfolio-app`
  - run `npm install` to instal node modules
  - run `npm start` to start the service on `localhost:3000`
    
##### deployed app : https://dbarochiya.github.io/me/
